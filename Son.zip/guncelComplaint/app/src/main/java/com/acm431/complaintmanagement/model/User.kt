package com.acm431.complaintmanagement.model

data class User(
    val username :String = "",
    val email : String = "",
    val password: String = "",
    val identityNumber: String = "",
)
